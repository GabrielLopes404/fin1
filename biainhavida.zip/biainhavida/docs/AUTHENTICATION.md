# 🔐 LUCREI - Authentication & Authorization Guide

## Table of Contents
- [Authentication Flow](#authentication-flow)
- [Authorization (RBAC)](#authorization-rbac)
- [API Endpoints](#api-endpoints)
- [Security Features](#security-features)
- [Integration Guide](#integration-guide)

---

## Authentication Flow

### User Registration Flow

```
1. User submits registration form
   POST /api/auth/register
   {
     "email": "user@example.com",
     "password": "SecurePass123!",
     "username": "johndoe",
     "name": "John Doe",
     "organizationName": "Acme Corp"
   }

2. Backend validates data
   - Email uniqueness check
   - Password strength validation
   - Username format check

3. Create organization
   - New organization created with user's email
   - Organization ID generated

4. Create user
   - Password hashed with bcrypt (12 rounds)
   - User created with role: OWNER
   - emailVerified: false
   - verificationToken generated

5. Send verification email
   - Email sent via Resend
   - Contains link: /verify-email?token={verificationToken}
   - Token expires in 24 hours

6. Auto-login
   - Session created automatically
   - User redirected to dashboard
   - Banner shown: "Please verify your email"

7. User clicks verification link
   GET /verify-email?token={token}
   
8. Backend verifies token
   - Token validated
   - emailVerified set to true
   - verificationToken cleared
   
9. User fully activated
   - Full access granted
   - Welcome email sent
```

**Sequence Diagram:**
```
User → Frontend → Backend → Database
                       ↓
                   Resend API
                       ↓
                   User Email
```

### Login Flow

```
1. User submits login form
   POST /api/login
   {
     "email": "user@example.com",
     "password": "SecurePass123!"
   }

2. Backend authenticates
   - Find user by email
   - Compare password hash (bcrypt)
   - Check if emailVerified === true

3. If email not verified:
   - Return error: "Email not verified"
   - Offer to resend verification email
   - Prevent login

4. If credentials valid:
   - Create session (PostgreSQL store)
   - Set session cookie (httpOnly, secure)
   - Return user object (no password)

5. Frontend stores user
   - User data in React Query cache
   - Redirect to dashboard

6. Subsequent requests
   - Session cookie automatically sent
   - Backend validates session
   - User data from req.user
```

### Password Reset Flow

```
1. User clicks "Forgot Password"
   
2. User enters email
   POST /api/auth/forgot-password
   {
     "email": "user@example.com"
   }

3. Backend generates reset token
   - resetToken: UUID
   - resetTokenExpiry: 1 hour from now
   - Save to database

4. Send reset email
   - Email sent via Resend
   - Contains link: /reset-password?token={resetToken}
   - Instructions for password reset

5. User clicks reset link
   GET /reset-password?token={token}
   
6. Frontend shows password reset form

7. User submits new password
   POST /api/auth/reset-password
   {
     "token": "uuid-token-here",
     "password": "NewSecurePass123!"
   }

8. Backend validates
   - Check token exists
   - Check token not expired
   - Validate password strength

9. Update password
   - Hash new password (bcrypt)
   - Clear resetToken and resetTokenExpiry
   - Invalidate all existing sessions

10. User redirected to login
    - Success message shown
    - Can login with new password
```

### Logout Flow

```
1. User clicks "Logout"
   POST /api/logout

2. Backend destroys session
   - Session removed from database
   - Session cookie cleared

3. Frontend clears state
   - React Query cache cleared
   - User redirected to login page
```

---

## Authorization (RBAC)

### Role Hierarchy

```
OWNER (Level 3 - Full Control)
  ↓
ADMIN (Level 2 - Administrative)
  ↓
CUSTOMER (Level 1 - Limited)
```

### Role Capabilities Matrix

| Capability | OWNER | ADMIN | CUSTOMER |
|------------|-------|-------|----------|
| **Organization** |
| View organization | ✅ | ✅ | ✅ |
| Edit organization | ✅ | ❌ | ❌ |
| Delete organization | ✅ | ❌ | ❌ |
| Manage billing | ✅ | ❌ | ❌ |
| **Users** |
| View all users | ✅ | ✅ | ❌ |
| Invite users | ✅ | ✅ | ❌ |
| Edit users | ✅ | ✅ | ❌ |
| Delete users | ✅ | ❌ | ❌ |
| Change user roles | ✅ | ❌ | ❌ |
| **Customers** |
| View all customers | ✅ | ✅ | ❌ |
| Create customers | ✅ | ✅ | ❌ |
| Edit customers | ✅ | ✅ | ❌ |
| Delete customers | ✅ | ✅ | ❌ |
| **Invoices** |
| View all invoices | ✅ | ✅ | Own only |
| Create invoices | ✅ | ✅ | ❌ |
| Edit invoices | ✅ | ✅ | Own only |
| Delete invoices | ✅ | ✅ | ❌ |
| Generate PDF | ✅ | ✅ | Own only |
| **Transactions** |
| View all transactions | ✅ | ✅ | Own only |
| Create transactions | ✅ | ✅ | Own only |
| Edit transactions | ✅ | ✅ | Own only |
| Delete transactions | ✅ | ✅ | ❌ |
| Bulk operations | ✅ | ✅ | ❌ |
| **Reports** |
| View DRE | ✅ | ✅ | ❌ |
| View Cash Flow | ✅ | ✅ | ❌ |
| View Statement | ✅ | ✅ | Own only |
| Export reports | ✅ | ✅ | ❌ |
| **Settings** |
| Categories | ✅ | ✅ | ❌ |
| Bank Accounts | ✅ | ✅ | ❌ |
| Cost Centers | ✅ | ✅ | ❌ |
| Tags | ✅ | ✅ | ❌ |
| API Keys | ✅ | ❌ | ❌ |
| **Data** |
| Import OFX | ✅ | ✅ | ❌ |
| Export data | ✅ | ✅ | Own only |
| Bulk upload | ✅ | ✅ | ❌ |

### Implementation

**Middleware Functions:**
```typescript
// Check if user is authenticated
function isAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

// Check if user is admin or owner
function isAdminOrOwner(req, res, next) {
  if (req.user && (req.user.role === "ADMIN" || req.user.role === "OWNER")) {
    return next();
  }
  res.status(403).json({ message: "Forbidden: Admin or Owner required" });
}

// Check if user is owner
function isOwner(req, res, next) {
  if (req.user && req.user.role === "OWNER") {
    return next();
  }
  res.status(403).json({ message: "Forbidden: Owner required" });
}
```

**Usage Example:**
```typescript
// Public route
app.get("/api/public/pricing", getPricing);

// Authenticated users only
app.get("/api/invoices", isAuthenticated, getInvoices);

// Admin/Owner only
app.post("/api/users/invite", isAuthenticated, isAdminOrOwner, inviteUser);

// Owner only
app.delete("/api/organization", isAuthenticated, isOwner, deleteOrganization);
```

**Organization-Level Isolation:**
```typescript
// All queries automatically filter by organizationId
async function getTransactions(req, res) {
  const { organizationId } = req.user;
  
  const transactions = await storage.getTransactionsByOrganization(
    organizationId
  );
  
  res.json(transactions);
}

// Users can only access data from their organization
// Cross-organization access is prevented at the database query level
```

---

## API Endpoints

### Authentication Endpoints

#### Register
```http
POST /api/auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePass123!",
  "username": "johndoe",
  "name": "John Doe",
  "organizationName": "Acme Corp"
}

Response 201:
{
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "username": "johndoe",
    "name": "John Doe",
    "organizationId": "org-uuid",
    "role": "OWNER"
  }
}
```

#### Login
```http
POST /api/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePass123!"
}

Response 200:
{
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "username": "johndoe",
    "name": "John Doe",
    "organizationId": "org-uuid",
    "role": "OWNER"
  }
}

Response 401:
{
  "message": "Invalid credentials"
}

Response 403:
{
  "message": "Email not verified. Please check your inbox."
}
```

#### Logout
```http
POST /api/logout

Response 200:
{
  "message": "Logged out successfully"
}
```

#### Forgot Password
```http
POST /api/auth/forgot-password
Content-Type: application/json

{
  "email": "user@example.com"
}

Response 200:
{
  "message": "Password reset email sent"
}
```

#### Reset Password
```http
POST /api/auth/reset-password
Content-Type: application/json

{
  "token": "reset-token-uuid",
  "password": "NewSecurePass123!"
}

Response 200:
{
  "message": "Password reset successfully"
}

Response 400:
{
  "message": "Invalid or expired token"
}
```

#### Get Current User
```http
GET /api/user
Authorization: Session Cookie

Response 200:
{
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "username": "johndoe",
    "name": "John Doe",
    "organizationId": "org-uuid",
    "role": "OWNER"
  }
}

Response 401:
{
  "message": "Unauthorized"
}
```

---

## Security Features

### 1. Password Security
- **Hashing**: bcrypt with 12 rounds (2^12 iterations)
- **Strength Requirements**:
  - Minimum 8 characters
  - At least 1 uppercase letter
  - At least 1 lowercase letter
  - At least 1 number
  - At least 1 special character
- **Never stored in plain text**
- **Never returned in API responses**

### 2. Session Management
- **Store**: PostgreSQL (persistent across restarts)
- **Cookie Settings**:
  - `httpOnly: true` (not accessible via JavaScript)
  - `secure: true` (production only, HTTPS required)
  - `sameSite: 'strict'` (CSRF protection)
  - `maxAge: 7 days`
- **Session Invalidation**: On password reset, all sessions destroyed

### 3. CSRF Protection
- **Method**: Double Submit Cookie Pattern
- **Token Generation**: Cryptographically secure (32 bytes)
- **Validation**: All state-changing requests (POST/PUT/DELETE/PATCH)
- **Excluded**: GET, HEAD, OPTIONS requests
- **Header**: `X-CSRF-Token` required

### 4. Rate Limiting
- **Global**: 100 requests/minute
- **Auth Endpoints**: 5 attempts/15 minutes
- **Email**: 10 emails/hour
- **Prevents**: Brute force attacks, abuse

### 5. Email Verification
- **Token**: UUID v4
- **Expiration**: 24 hours
- **One-time use**: Token invalidated after use
- **Prevents**: Fake accounts, spam

### 6. Password Reset
- **Token**: UUID v4
- **Expiration**: 1 hour
- **One-time use**: Token invalidated after use
- **Session Invalidation**: All sessions destroyed on reset

### 7. Organization Isolation
- **Multi-tenancy**: Each organization's data completely isolated
- **Automatic Filtering**: All queries filter by `organizationId`
- **No Cross-Organization Access**: Enforced at database level
- **Prevents**: Data leaks between organizations

---

## Integration Guide

### Frontend Integration (React)

```typescript
// Login
const login = async (email: string, password: string) => {
  const response = await fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include', // IMPORTANT: Include cookies
    body: JSON.stringify({ email, password })
  });
  
  if (!response.ok) {
    throw new Error('Login failed');
  }
  
  return response.json();
};

// Protected API call
const getInvoices = async () => {
  const response = await fetch('/api/invoices', {
    credentials: 'include' // IMPORTANT: Include cookies
  });
  
  if (response.status === 401) {
    // Redirect to login
    window.location.href = '/login';
    return;
  }
  
  return response.json();
};

// Logout
const logout = async () => {
  await fetch('/api/logout', {
    method: 'POST',
    credentials: 'include'
  });
  
  // Clear local state
  queryClient.clear();
  window.location.href = '/login';
};
```

### API Key Authentication (for integrations)

```typescript
// Generate API key (Owner only)
POST /api/api-keys
{
  "name": "Mobile App Integration"
}

Response:
{
  "id": "key-uuid",
  "name": "Mobile App Integration",
  "key": "luc_live_abc123xyz789..." // Save this! Shown only once
}

// Use API key
GET /api/invoices
Authorization: Bearer luc_live_abc123xyz789...

// Revoke API key
DELETE /api/api-keys/{keyId}
```

---

## Testing Checklist

### Manual Testing

- [ ] Register new account
- [ ] Verify email link works
- [ ] Login with correct credentials
- [ ] Login fails with wrong password
- [ ] Login blocked if email not verified
- [ ] Forgot password sends email
- [ ] Reset password link works
- [ ] Reset password expires after 1 hour
- [ ] Old password doesn't work after reset
- [ ] Logout clears session
- [ ] Session persists after server restart
- [ ] CSRF token validates correctly
- [ ] Rate limiting prevents brute force
- [ ] Organization isolation prevents data leaks
- [ ] RBAC enforces permissions correctly

### Automated Testing (when implemented)

```typescript
// Example tests
describe('Authentication', () => {
  it('should register new user', async () => {
    // Test registration flow
  });
  
  it('should login with valid credentials', async () => {
    // Test login
  });
  
  it('should reject login without email verification', async () => {
    // Test email verification requirement
  });
  
  // ... more tests
});
```

---

**Last Updated:** November 4, 2025  
**Version:** 1.0.0
