interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

export async function sendEmail(options: EmailOptions): Promise<boolean> {
  if (process.env.NODE_ENV === "development") {
    console.log("📧 [DEV] Email would be sent:");
    console.log(`  To: ${options.to}`);
    console.log(`  Subject: ${options.subject}`);
    console.log(`  Content: ${options.text || options.html.substring(0, 100)}...`);
    return true;
  }

  const resendApiKey = process.env.RESEND_API_KEY;
  
  if (!resendApiKey) {
    return false;
  }

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${resendApiKey}`,
      },
      body: JSON.stringify({
        from: process.env.EMAIL_FROM || "noreply@lucrei.app",
        to: options.to,
        subject: options.subject,
        html: options.html,
        text: options.text,
      }),
    });

    if (!response.ok) {
      return false;
    }

    return true;
  } catch (error) {
    return false;
  }
}

export function generatePasswordResetEmail(resetLink: string, userName: string): EmailOptions["html"] {
  return `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Redefinir Senha - LUCREI</title>
      </head>
      <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">LUCREI</h1>
          <p style="color: #f0f0f0; margin: 10px 0 0 0;">Sistema de Gestão Financeira</p>
        </div>
        
        <div style="background: #ffffff; padding: 40px; border: 1px solid #e0e0e0; border-top: none; border-radius: 0 0 8px 8px;">
          <h2 style="color: #333; margin-top: 0;">Olá, ${userName}!</h2>
          
          <p>Recebemos uma solicitação para redefinir a senha da sua conta no LUCREI.</p>
          
          <p>Clique no botão abaixo para criar uma nova senha:</p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${resetLink}" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 14px 30px; text-decoration: none; border-radius: 6px; font-weight: 600; display: inline-block;">
              Redefinir Senha
            </a>
          </div>
          
          <p style="color: #666; font-size: 14px;">
            Este link é válido por 1 hora. Se você não solicitou a redefinição de senha, ignore este e-mail.
          </p>
          
          <p style="color: #666; font-size: 14px; margin-top: 30px;">
            Se o botão não funcionar, copie e cole o link abaixo no seu navegador:<br>
            <a href="${resetLink}" style="color: #667eea; word-break: break-all;">${resetLink}</a>
          </p>
        </div>
        
        <div style="text-align: center; padding: 20px; color: #999; font-size: 12px;">
          <p>© 2025 LUCREI. Todos os direitos reservados.</p>
        </div>
      </body>
    </html>
  `;
}

export function generateEmailVerificationEmail(verifyLink: string, userName: string): EmailOptions["html"] {
  return `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Verificar Email - LUCREI</title>
      </head>
      <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">LUCREI</h1>
          <p style="color: #f0f0f0; margin: 10px 0 0 0;">Sistema de Gestão Financeira</p>
        </div>
        
        <div style="background: #ffffff; padding: 40px; border: 1px solid #e0e0e0; border-top: none; border-radius: 0 0 8px 8px;">
          <h2 style="color: #333; margin-top: 0;">Bem-vindo, ${userName}!</h2>
          
          <p>Obrigado por se registrar no LUCREI! Para começar a usar sua conta, precisamos verificar seu endereço de e-mail.</p>
          
          <p>Clique no botão abaixo para verificar seu e-mail:</p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${verifyLink}" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 14px 30px; text-decoration: none; border-radius: 6px; font-weight: 600; display: inline-block;">
              Verificar E-mail
            </a>
          </div>
          
          <p style="color: #666; font-size: 14px;">
            Este link é válido por 24 horas. Após a verificação, você terá acesso completo à plataforma.
          </p>
          
          <p style="color: #666; font-size: 14px; margin-top: 30px;">
            Se o botão não funcionar, copie e cole o link abaixo no seu navegador:<br>
            <a href="${verifyLink}" style="color: #667eea; word-break: break-all;">${verifyLink}</a>
          </p>
        </div>
        
        <div style="text-align: center; padding: 20px; color: #999; font-size: 12px;">
          <p>© 2025 LUCREI. Todos os direitos reservados.</p>
        </div>
      </body>
    </html>
  `;
}

export function generateWelcomeEmail(userName: string): EmailOptions["html"] {
  return `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bem-vindo ao LUCREI</title>
      </head>
      <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">🎉 Bem-vindo ao LUCREI!</h1>
        </div>
        
        <div style="background: #ffffff; padding: 40px; border: 1px solid #e0e0e0; border-top: none; border-radius: 0 0 8px 8px;">
          <h2 style="color: #333; margin-top: 0;">Olá, ${userName}!</h2>
          
          <p>Seu e-mail foi verificado com sucesso! Agora você tem acesso completo ao LUCREI.</p>
          
          <h3 style="color: #667eea; margin-top: 30px;">Próximos Passos:</h3>
          <ul style="line-height: 2;">
            <li>Configure sua organização</li>
            <li>Adicione suas contas bancárias</li>
            <li>Cadastre suas categorias de despesas</li>
            <li>Comece a registrar suas transações</li>
          </ul>
          
          <p style="margin-top: 30px;">Se precisar de ajuda, nossa equipe de suporte está sempre disponível.</p>
          
          <p style="color: #666; font-size: 14px; margin-top: 40px;">
            Aproveite ao máximo o LUCREI!<br>
            Equipe LUCREI
          </p>
        </div>
        
        <div style="text-align: center; padding: 20px; color: #999; font-size: 12px;">
          <p>© 2025 LUCREI. Todos os direitos reservados.</p>
        </div>
      </body>
    </html>
  `;
}

interface InvoiceData {
  invoiceNumber: string;
  customerName: string;
  customerEmail: string;
  amount: string;
  dueDate: string;
  description: string;
  issueDate: string;
  organizationName: string;
}

export function generateInvoiceEmail(invoice: InvoiceData): EmailOptions["html"] {
  return `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Fatura ${invoice.invoiceNumber}</title>
      </head>
      <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 8px 8px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">${invoice.organizationName}</h1>
          <p style="color: #f0f0f0; margin: 10px 0 0 0;">Nova Fatura Disponível</p>
        </div>
        
        <div style="background: #ffffff; padding: 40px; border: 1px solid #e0e0e0; border-top: none; border-radius: 0 0 8px 8px;">
          <h2 style="color: #333; margin-top: 0;">Olá, ${invoice.customerName}!</h2>
          
          <p>Uma nova fatura foi emitida para você.</p>
          
          <div style="background: #f8f9fa; padding: 20px; border-radius: 6px; margin: 25px 0;">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 8px 0; color: #666;">Número da Fatura:</td>
                <td style="padding: 8px 0; font-weight: 600; text-align: right;">${invoice.invoiceNumber}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; color: #666;">Data de Emissão:</td>
                <td style="padding: 8px 0; text-align: right;">${invoice.issueDate}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; color: #666;">Vencimento:</td>
                <td style="padding: 8px 0; text-align: right; font-weight: 600;">${invoice.dueDate}</td>
              </tr>
              <tr style="border-top: 2px solid #e0e0e0;">
                <td style="padding: 12px 0; color: #667eea; font-size: 18px; font-weight: 600;">Valor Total:</td>
                <td style="padding: 12px 0; text-align: right; color: #667eea; font-size: 22px; font-weight: 700;">R$ ${invoice.amount}</td>
              </tr>
            </table>
          </div>
          
          <p style="margin: 25px 0;">
            <strong>Descrição:</strong><br>
            ${invoice.description || 'N/A'}
          </p>
          
          <p style="color: #666; font-size: 14px; margin-top: 30px;">
            Por favor, efetue o pagamento até a data de vencimento.
          </p>
          
          <p style="color: #666; font-size: 14px;">
            Em caso de dúvidas, entre em contato conosco.
          </p>
        </div>
        
        <div style="text-align: center; padding: 20px; color: #999; font-size: 12px;">
          <p>© 2025 ${invoice.organizationName}. Todos os direitos reservados.</p>
        </div>
      </body>
    </html>
  `;
}
